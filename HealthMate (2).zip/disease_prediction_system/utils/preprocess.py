import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, MultiLabelBinarizer
import json
import warnings
warnings.filterwarnings('ignore')

def load_and_preprocess_data(data_path='data/dataset.csv'):
    """
    Load and preprocess the dataset
    Returns: DataFrame with cleaned data
    """
    print("Loading dataset...")
    df = pd.read_csv(data_path)
    
    # Clean column names
    df.columns = [col.strip() for col in df.columns]
    
    # Clean disease names (remove trailing spaces)
    df['Disease'] = df['Disease'].astype(str).str.strip()
    
    # Clean symptom values
    symptom_cols = [col for col in df.columns if col.startswith('Symptom_')]
    for col in symptom_cols:
        df[col] = df[col].astype(str).str.strip()
        df[col] = df[col].replace('nan', np.nan)
    
    print(f"Dataset loaded: {len(df)} records, {len(df['Disease'].unique())} diseases")
    return df, symptom_cols

def extract_all_symptoms(df, symptom_cols):
    """
    Extract all unique symptoms from the dataset
    Returns: List of all unique symptoms
    """
    print("Extracting symptoms...")
    
    all_symptoms = set()
    
    # Extract symptoms from each row
    for _, row in df.iterrows():
        symptoms = []
        for col in symptom_cols:
            symptom = row[col]
            if pd.notna(symptom) and str(symptom).strip() and str(symptom).strip().lower() != 'nan':
                symptoms.append(str(symptom).strip())
        
        all_symptoms.update(symptoms)
    
    # Clean and sort symptoms
    all_symptoms = sorted([s for s in all_symptoms if s])
    print(f"Found {len(all_symptoms)} unique symptoms")
    
    return all_symptoms

def create_feature_matrix(df, symptom_cols, all_symptoms):
    """
    Create feature matrix (X) and target vector (y)
    Returns: X (features), y (target), label_encoder
    """
    print("Creating feature matrix...")
    
    X = []
    y = []
    
    # Create a dictionary for faster lookup
    symptom_to_idx = {symptom: i for i, symptom in enumerate(all_symptoms)}
    
    for idx, row in df.iterrows():
        # Extract symptoms for this row
        symptoms = []
        for col in symptom_cols:
            symptom = row[col]
            if pd.notna(symptom) and str(symptom).strip() and str(symptom).strip().lower() != 'nan':
                symptoms.append(str(symptom).strip())
        
        # Create binary vector
        symptom_vector = np.zeros(len(all_symptoms), dtype=int)
        for symptom in symptoms:
            if symptom in symptom_to_idx:
                symptom_vector[symptom_to_idx[symptom]] = 1
        
        X.append(symptom_vector)
        y.append(row['Disease'])
    
    X = np.array(X)
    
    # Encode target labels
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)
    
    print(f"Feature matrix shape: {X.shape}")
    print(f"Number of classes: {len(label_encoder.classes_)}")
    
    return X, y_encoded, label_encoder

def create_symptom_encoder(all_symptoms):
    """
    Create a symptom encoder
    Returns: MultiLabelBinarizer fitted with all symptoms
    """
    symptom_encoder = MultiLabelBinarizer()
    symptom_encoder.fit([all_symptoms])
    return symptom_encoder

def save_symptom_list(all_symptoms, filepath='model/symptoms.json'):
    """
    Save the list of all symptoms to a JSON file
    """
    with open(filepath, 'w') as f:
        json.dump(all_symptoms, f, indent=2)
    print(f"Symptoms list saved to {filepath}")

def get_disease_severity_mapping(severity_path='data/disease_severity.csv'):
    """
    Load disease severity mapping
    Returns: Dictionary mapping disease names to severity levels
    """
    try:
        severity_df = pd.read_csv(severity_path)
        severity_mapping = dict(zip(severity_df['Disease'], severity_df['Severity']))
        print(f"Loaded severity mapping for {len(severity_mapping)} diseases")
        return severity_mapping
    except FileNotFoundError:
        print(f"Warning: Severity file not found at {severity_path}")
        return {}
    except Exception as e:
        print(f"Error loading severity file: {str(e)}")
        return {}

def get_symptom_disease_frequency(df, symptom_cols):
    """
    Calculate symptom frequency across diseases
    Returns: Dictionary with symptom frequencies
    """
    symptom_freq = {}
    
    for _, row in df.iterrows():
        disease = row['Disease']
        symptoms = set()
        
        for col in symptom_cols:
            symptom = row[col]
            if pd.notna(symptom) and str(symptom).strip() and str(symptom).strip().lower() != 'nan':
                symptom_name = str(symptom).strip()
                symptoms.add(symptom_name)
                
                if symptom_name not in symptom_freq:
                    symptom_freq[symptom_name] = {'count': 0, 'diseases': set()}
                
                symptom_freq[symptom_name]['count'] += 1
                symptom_freq[symptom_name]['diseases'].add(disease)
    
    # Convert sets to lists for JSON serialization
    for symptom in symptom_freq:
        symptom_freq[symptom]['diseases'] = list(symptom_freq[symptom]['diseases'])
    
    return symptom_freq

def get_disease_symptom_summary(df, symptom_cols):
    """
    Get summary of symptoms per disease
    Returns: Dictionary with disease symptom information
    """
    disease_summary = {}
    
    for _, row in df.iterrows():
        disease = row['Disease']
        symptoms = []
        
        for col in symptom_cols:
            symptom = row[col]
            if pd.notna(symptom) and str(symptom).strip() and str(symptom).strip().lower() != 'nan':
                symptoms.append(str(symptom).strip())
        
        if disease not in disease_summary:
            disease_summary[disease] = {
                'symptoms': set(symptoms),
                'symptom_count': len(symptoms),
                'frequency': 0
            }
        
        disease_summary[disease]['frequency'] += 1
        disease_summary[disease]['symptoms'].update(symptoms)
    
    # Convert sets to lists
    for disease in disease_summary:
        disease_summary[disease]['symptoms'] = list(disease_summary[disease]['symptoms'])
    
    return disease_summary

def preprocess_pipeline(data_path='data/dataset.csv'):
    """
    Complete preprocessing pipeline
    Returns: X, y, label_encoder, symptom_encoder, all_symptoms
    """
    print("=" * 50)
    print("STARTING DATA PREPROCESSING")
    print("=" * 50)
    
    # Step 1: Load data
    df, symptom_cols = load_and_preprocess_data(data_path)
    
    # Step 2: Extract all symptoms
    all_symptoms = extract_all_symptoms(df, symptom_cols)
    
    # Step 3: Create feature matrix
    X, y, label_encoder = create_feature_matrix(df, symptom_cols, all_symptoms)
    
    # Step 4: Create symptom encoder
    symptom_encoder = create_symptom_encoder(all_symptoms)
    
    # Step 5: Get additional information
    severity_mapping = get_disease_severity_mapping()
    symptom_freq = get_symptom_disease_frequency(df, symptom_cols)
    disease_summary = get_disease_symptom_summary(df, symptom_cols)
    
    # Save metadata
    save_symptom_list(all_symptoms)
    
    # Print summary
    print("\n" + "=" * 50)
    print("PREPROCESSING SUMMARY")
    print("=" * 50)
    print(f"Total samples: {len(X)}")
    print(f"Total diseases: {len(label_encoder.classes_)}")
    print(f"Total symptoms: {len(all_symptoms)}")
    print(f"Feature matrix shape: {X.shape}")
    print(f"Diseases with severity info: {len(severity_mapping)}")
    print("=" * 50)
    
    return X, y, label_encoder, symptom_encoder, all_symptoms, df, severity_mapping

if __name__ == '__main__':
    # Test the preprocessing pipeline
    X, y, label_encoder, symptom_encoder, all_symptoms, df, severity_mapping = preprocess_pipeline()
    
    print("\nFirst 10 diseases:")
    for i, disease in enumerate(label_encoder.classes_[:10]):
        print(f"  {i+1}. {disease}")
    
    print("\nFirst 20 symptoms:")
    for i, symptom in enumerate(all_symptoms[:20]):
        print(f"  {i+1}. {symptom}")
    
    print(f"\nSample severity mapping (first 5):")
    for i, (disease, severity) in enumerate(list(severity_mapping.items())[:5]):
        print(f"  {disease}: {severity}")