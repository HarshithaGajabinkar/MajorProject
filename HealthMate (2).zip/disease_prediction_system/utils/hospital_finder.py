# utils/hospital_finder.py - NEW FILE
import requests
import json
from geopy.geocoders import Nominatim
from geopy.distance import geodesic
import time
from typing import List, Dict, Optional, Tuple
import random

class HospitalFinder:
    """Find nearby hospitals using various APIs"""
    
    def __init__(self, config):
        self.config = config
        self.geolocator = Nominatim(user_agent="disease_predictor_app")
        self.cache = {}
        
    def get_user_location(self) -> Optional[Tuple[float, float]]:
        """
        Get user's location. In a real app, this would come from browser geolocation.
        For demo purposes, we'll use IP geolocation or default location.
        """
        try:
            # Try to get location from IP (for demo)
            response = requests.get('https://ipinfo.io/json', timeout=5)
            if response.status_code == 200:
                data = response.json()
                loc = data.get('loc', '').split(',')
                if len(loc) == 2:
                    return float(loc[0]), float(loc[1])
        except:
            pass
        
        # Default to New York City coordinates if can't detect
        return (40.7128, -74.0060)  # NYC
        
    def search_nearby_hospitals_openstreetmap(self, 
                                             lat: float, 
                                             lon: float, 
                                             radius: int = 5000,
                                             max_results: int = 10) -> List[Dict]:
        """Search for hospitals using OpenStreetMap Overpass API"""
        hospitals = []
        
        # Overpass API query for hospitals/clinics
        overpass_query = f"""
        [out:json];
        (
          node["amenity"="hospital"](around:{radius},{lat},{lon});
          node["amenity"="clinic"](around:{radius},{lat},{lon});
          node["healthcare"="hospital"](around:{radius},{lat},{lon});
          node["healthcare"="clinic"](around:{radius},{lat},{lon});
        );
        out body;
        """
        
        try:
            response = requests.post(
                'https://overpass-api.de/api/interpreter',
                data={'data': overpass_query},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                for element in data.get('elements', []):
                    if element['type'] == 'node':
                        hospital = {
                            'name': element.get('tags', {}).get('name', 'Unknown Hospital'),
                            'latitude': element['lat'],
                            'longitude': element['lon'],
                            'address': element.get('tags', {}).get('addr:full', 
                                    f"{element.get('tags', {}).get('addr:street', '')}, "
                                    f"{element.get('tags', {}).get('addr:city', '')}"),
                            'phone': element.get('tags', {}).get('phone', 'N/A'),
                            'website': element.get('tags', {}).get('website', ''),
                            'type': element.get('tags', {}).get('amenity', 
                                   element.get('tags', {}).get('healthcare', 'hospital')),
                            'distance_km': round(geodesic((lat, lon), 
                                                         (element['lat'], element['lon'])).km, 2)
                        }
                        hospitals.append(hospital)
                        
                # Sort by distance
                hospitals.sort(key=lambda x: x['distance_km'])
                
        except Exception as e:
            print(f"Error searching OSM hospitals: {e}")
            
        return hospitals[:max_results]
    
    def search_google_places_hospitals(self, lat: float, lon: float, radius: int = 5000) -> List[Dict]:
        """Search for hospitals using Google Places API (requires API key)"""
        if not self.config.GOOGLE_MAPS_API_KEY:
            return []
            
        hospitals = []
        url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
        
        params = {
            'location': f"{lat},{lon}",
            'radius': radius,
            'type': 'hospital',
            'keyword': 'hospital clinic emergency',
            'key': self.config.GOOGLE_MAPS_API_KEY
        }
        
        try:
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                for place in data.get('results', []):
                    hospital = {
                        'name': place.get('name', 'Unknown Hospital'),
                        'latitude': place['geometry']['location']['lat'],
                        'longitude': place['geometry']['location']['lng'],
                        'address': place.get('vicinity', 'Address not available'),
                        'rating': place.get('rating', 'N/A'),
                        'open_now': place.get('opening_hours', {}).get('open_now', False),
                        'place_id': place.get('place_id', ''),
                        'distance_km': round(geodesic((lat, lon), 
                                                     (place['geometry']['location']['lat'],
                                                      place['geometry']['location']['lng'])).km, 2)
                    }
                    hospitals.append(hospital)
                    
        except Exception as e:
            print(f"Error searching Google Places: {e}")
            
        return hospitals
    
    def get_sample_hospitals(self, lat: float, lon: float) -> List[Dict]:
        """Return sample hospitals for demo/testing"""
        sample_names = [
            "City General Hospital",
            "Community Medical Center",
            "Unity Health Clinic",
            "Regional Emergency Hospital",
            "Family Care Medical Center",
            "Hope Medical Clinic",
            "Health First Hospital",
            "MediCare Urgent Care",
            "Sunrise Medical Center",
            "Wellness Hospital"
        ]
        
        hospitals = []
        for i, name in enumerate(sample_names[:8]):
            # Generate random nearby coordinates (within 10km)
            offset_lat = lat + random.uniform(-0.09, 0.09)  # ~10km
            offset_lon = lon + random.uniform(-0.09, 0.09)  # ~10km
            
            hospitals.append({
                'name': name,
                'latitude': offset_lat,
                'longitude': offset_lon,
                'address': f"{i+100} Medical Center Dr, Healthcare City",
                'phone': f"(555) 123-{i:04d}",
                'website': f"https://www.{name.lower().replace(' ', '')}.com",
                'type': 'hospital' if i < 5 else 'clinic',
                'distance_km': round(geodesic((lat, lon), (offset_lat, offset_lon)).km, 2),
                'rating': round(random.uniform(3.5, 5.0), 1),
                'open_now': random.choice([True, False]),
                'emergency': random.choice([True, False])
            })
        
        # Sort by distance
        hospitals.sort(key=lambda x: x['distance_km'])
        return hospitals
    
    def find_nearby_hospitals(self, max_results: int = 10) -> List[Dict]:
        """Main method to find nearby hospitals"""
        try:
            user_location = self.get_user_location()
            if not user_location:
                return []
                
            lat, lon = user_location
            
            # Try different methods based on configuration
            hospitals = []
            
            if self.config.MAP_PROVIDER == 'google' and self.config.GOOGLE_MAPS_API_KEY:
                hospitals = self.search_google_places_hospitals(lat, lon, self.config.DEFAULT_SEARCH_RADIUS)
            else:
                hospitals = self.search_nearby_hospitals_openstreetmap(lat, lon, 
                                                                      self.config.DEFAULT_SEARCH_RADIUS)
            
            # If no hospitals found or for demo, use sample data
            if not hospitals:
                hospitals = self.get_sample_hospitals(lat, lon)
            
            # Add user location as first item
            hospitals.insert(0, {
                'name': 'Your Location',
                'latitude': lat,
                'longitude': lon,
                'address': 'Current Location',
                'type': 'user',
                'distance_km': 0,
                'is_user': True
            })
            
            return hospitals[:max_results]
            
        except Exception as e:
            print(f"Error finding hospitals: {e}")
            return []
    
    def get_directions_url(self, destination_lat: float, destination_lon: float) -> str:
        """Generate directions URL based on map provider"""
        user_location = self.get_user_location()
        if not user_location:
            return ""
            
        lat, lon = user_location
        
        if self.config.MAP_PROVIDER == 'google':
            return (f"https://www.google.com/maps/dir/"
                   f"{lat},{lon}/"
                   f"{destination_lat},{destination_lon}")
        else:
            return (f"https://www.openstreetmap.org/directions?"
                   f"engine=fossgis_osrm_car&route="
                   f"{lat},{lon};{destination_lat},{destination_lon}")